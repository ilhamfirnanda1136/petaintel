<!DOCTYPE html>
<html>
<head>
    <title>DPRD {{config('global.kota')}}</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/x-icon" href="docs/images/favicon.ico" />

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.5.1/dist/leaflet.css" integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ==" crossorigin=""/>
    <script src="https://unpkg.com/leaflet@1.5.1/dist/leaflet.js" integrity="sha512-GffPMF3RvMeYyc1LWMHtK8EbPv0iNZ8/oTtHPx9/cc2ILxQ+u905qIwdpULaqDkyBKgOaB57QTMg7ztg8Jm2Og==" crossorigin=""></script>

<style>

body {
  margin: 0;
}
html, body, #map {
  height: 100%;
}
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}


#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
    </style>
</head>
<body>
    <div id="map"></div>
    <script type="text/javascript" src="{{asset('js/bantenkota.js')}}"></script>
<script type="text/javascript">

  var map = L.map('map').setView([-6.1721646,106.151813], 9);

  L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 20,
    attribution: '<a href>Kejati Banten</a>',
    id: 'mapbox.light'
  }).addTo(map);

 function getColor(d) {
    return d == 'Cilegon' ? '#6a00b0' :
           d == 'Kota Serang' ? '#D597F9' :
           d == 'Kota Tangerang' ? '#00c954' :
           d == 'Lebak' ? '#EC9949' :
           d == 'Pandeglang' ? '#4C51EF' :
           d == 'Serang' ? '#EF4242' :
           d == 'Tangerang' ? '#EEF72E' : '#00d0ff' ;
  }
  var geojson;

  geojson = L.geoJson(banten, {
    style: function (feature) {
              kota = feature.properties.NAME_2;
              return {
                fillColor: getColor(kota),
                fillOpacity: 0.5,
                color: "white",
                dashArray: '3',
                weight: 1,
                opacity: 0.7
              }
          }
  }).addTo(map);

var kosong =L.icon({
    iconUrl:"{{asset('img/asing.png')}}",
    iconSize:[25,25]
})

  fetch("{{url('muat/orangasing')}}/{{$satker}}/{{$tahun}}")
  .then(res => res.json())
  .then((data) => {
    data.forEach(element => {
        L.marker([element.lat,element.lang],{icon:kosong}).addTo(map)
        .bindPopup(`<b>Nama Lengkap : ${element.nama}</b><br><b>Alamat : ${element.alamat}</b><br><b>Jenis Kelamin : ${element.kelamin}</b><br><b>kebangsaan : ${element.kebangsaan}</b></br><b>Maksud dan Tujuan : ${element.maksud_tujuan}</b><br> <b>Kecamatan : ${element.nama_kecamatan}</b><br><b>Nama Kota : ${element.nama_kota}</b>`, {autoClose:false});
    });
  })
  .catch((err) => console.log(err))

</script>

  </body>
</html>
