@extends('layouts.template')
@section('content')
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.5.1/dist/leaflet.css"
    integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
    crossorigin="" />
<div class="container">
    <div class="row justify-content-center">
    <div class="col-md-12 grid-margin">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">Peta LSM/ORMAS</div>
                    <div id="map" class="maps-leaflet-container"></div>
                </div>
            </div>
        </div>
        <div class="col-md-12 grid-margin">
            <div class="card">
            <div class="card-header">
                <div class="float-right">
                <a href="{{url('tambah/peta/lsm')}}" class="btn btn-primary" id="tambah-jenis"><i class="fa fa-plus"></i> Tambah Data Peta lsm</a>
                </div>
            </div>
                <div class="card-body">
                    <h4 class="card-title">Data Peta lsm/Ormas</h4>
                    <div class="table-responsive">
                        <table id="lsm" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>No #</th>
                                    <th>Wilayah</th>
                                    <th>Nama Lsm Ormas</th>
                                    <th>Alamat</th>
                                    <th>NO SKT</th>
                                    <th>TGL SKT</th>
                                    <th>keterangan</th>
                                    <th>Bulan dan Tahun</th>
                                    <th>Kategori LSM  </th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="tbody">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@stop
@section('footer')
<script src="https://unpkg.com/leaflet@1.5.1/dist/leaflet.js"
    integrity="sha512-GffPMF3RvMeYyc1LWMHtK8EbPv0iNZ8/oTtHPx9/cc2ILxQ+u905qIwdpULaqDkyBKgOaB57QTMg7ztg8Jm2Og=="
    crossorigin=""></script>
<script type="text/javascript" src="{{asset('js/bantenkota.js')}}"></script>
<script>
document.querySelector('.maps-leaflet-container').style.height = '450px';
  var map = L.map('map').setView([-6.1721646,106.151813], 9);

  L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 20,
    attribution: '<a href>Kejati Banten</a>',
    id: 'mapbox.light'
  }).addTo(map);



 function getColor(d) {
    return d == 'Cilegon' ? '#6a00b0' :
           d == 'Kota Serang' ? '#D597F9' :
           d == 'Kota Tangerang' ? '#00c954' :
           d == 'Lebak' ? '#EC9949' :
           d == 'Pandeglang' ? '#4C51EF' :
           d == 'Serang' ? '#EF4242' :
           d == 'Tangerang' ? '#EEF72E' : '#00d0ff' ;
  }
  var geojson;

  geojson = L.geoJson(banten, {
    style: function (feature) {
              kota = feature.properties.NAME_2;
              return {
                fillColor: getColor(kota),
                fillOpacity: 0.5,
                color: "white",
                dashArray: '3',
                weight: 1,
                opacity: 0.7
              }
          }
  }).addTo(map);

var kosong =L.icon({
    iconUrl:"{{asset('img/pinmap.png')}}",
    iconSize:[25,25]
})

  fetch("{{url('muat/lsm')}}/{{Auth::user()->satker_id}}/kosong")
  .then(res => res.json())
  .then((data) => {
    data.forEach(element => {
        L.marker([element.lat,element.lang],{icon:kosong}).addTo(map)
        .bindPopup(`<b>Kategori LSM: ${element.deskripsi_lsm}</b><br><b>Alamat : ${element.alamat}</b><br><b>No SKT : ${element.no_skt}</b><br><b>Tanggal SKT : ${element.tgl_skt}</b><br><b>Keterangan : ${element.keterangan}</b></br>
        <b>Kecamatan : ${element.nama_kecamatan}</b><br><b>Nama Kota : ${element.nama_kota}</b>`, {autoClose:false}).openPopup();
    });
  })
  .catch((err) => console.log(err))

    $(document).ready(function(){
        $('#lsm').DataTable({
            processing: true,
            serverSide: true,
            responsive:true,
            ajax: process_env_url + "/table/lsm",
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'id'
                },
                {
                    data: 'wilayah',
                    name: 'wilayah'
                },
                 {
                     data: 'nama_lsm',
                     name: 'nama_lsm'
                 },
                  {
                     data: 'alamat',
                     name: 'alamat'
                 },
                  {
                     data: 'no_skt',
                     name: 'no_skt'
                 },
                  {
                     data: 'tgl_skt',
                     name: 'tgl_skt'
                 },
                {
                    data: 'keterangan',
                    name: 'keterangan'
                },
                {
                    data: 'bulantahun',
                    name: 'bulantahun'
                },
                {
                    data: 'jenislsm',
                    name: 'jenislsm'
                },
                {
                    data: 'action',
                    name: 'action'
                },
            ],
            "order": [
                [0, "desc"]
            ],
        });

        $('body').on('click','.btn-delete',function(){
        const url = process_env_url + '/hapus/lsm/' + $(this).data('id');
          swal({
                  title: "Are you sure?",
                  text: "Ingin Menghapus? , anda akan kehilangan data Peta lsm!",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
              })
              .then((willDelete) => {
                  if (willDelete) {
                    loading();
                    fetch(url, {
                            method: "GET",
                            headers: {
                                'Content-type': 'application/json'
                            },
                        })
                        .then(res => res.json())
                        .then((data) => {
                            matikanLoading();
                            $('#lsm').DataTable().ajax.reload();
                            swal({
                                title: "Pesan!",
                                text: data.message,
                                icon: "success",
                            });
                        });
                } else {
                    swal({
                        title: "Pesan!",
                        text: "anda telah membatalkan menghapus jenis lsm ",
                        icon: "success",
                    });
                 }
            })
        })
    })
</script>
@endsection
